﻿using KeyboardApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Windows.Forms;


namespace KeyboardApi.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
            
        }

        // GET api/values/5
        public Retorno Get(string id)
        {
            Retorno r = new Retorno() { id = (int) HttpStatusCode.OK, mensaje = "OK" };
            SendKeys.SendWait("A");
            return r;
        }

     
    }
}