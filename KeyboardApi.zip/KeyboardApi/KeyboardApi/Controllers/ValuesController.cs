﻿using KeyboardApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Windows.Forms;
using Libreria;
using System.Runtime.InteropServices;


namespace KeyboardApi.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };

        }

        // GET api/values/5
        public Retorno Get(string id)
        {
            Retorno r = new Retorno() { id = (int)HttpStatusCode.OK, mensaje = "OK" };
            Enviar(id);
            //SendKeys.SendWait("A");
            return r;
        }

        private void Enviar(string id)
        {
            NativeMethods.CHANGEFILTERSTRUCT changeFilter = new NativeMethods.CHANGEFILTERSTRUCT();
            changeFilter.size = (uint)Marshal.SizeOf(changeFilter);
            changeFilter.info = 0;
            //if (!NativeMethods.ChangeWindowMessageFilterEx((IntPtr )0xffff, NativeMethods.WM_COPYDATA,  NativeMethods.ChangeWindowMessageFilterExAction.Allow, ref changeFilter))
            //{
            //    int error = Marshal.GetLastWin32Error();
            //    MessageBox.Show(String.Format("The error {0} occurred.", error));
            //}
            //else
            //{
                string windowTitle = "Server Side";
                // Find the window with the name of the main form
                IntPtr ptrWnd = NativeMethods .FindWindow(null, windowTitle);
                if (ptrWnd == IntPtr.Zero)
                {
                    MessageBox.Show(String.Format("No window found with the title {0}.", windowTitle),
                    "SendMessage Demo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    IntPtr ptrCopyData = IntPtr.Zero;
                    try
                    {
                        // Create the data structure and fill with data
                        NativeMethods.COPYDATASTRUCT copyData = new NativeMethods.COPYDATASTRUCT();
                        copyData.dwData = new IntPtr(2);    // Just a number to identify the data type
                        copyData.cbData = id.Length + 1;  // One extra byte for the \0 character
                        copyData.lpData = Marshal.StringToHGlobalAnsi(id);

                        // Allocate memory for the data and copy
                        ptrCopyData = Marshal.AllocCoTaskMem(Marshal.SizeOf(copyData));
                        Marshal.StructureToPtr(copyData, ptrCopyData, false);

                        // Send the message
                        NativeMethods.SendMessage(ptrWnd, NativeMethods .WM_COPYDATA, IntPtr.Zero, ptrCopyData);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString(), "SendMessage Demo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        // Free the allocated memory after the control has been returned
                        if (ptrCopyData != IntPtr.Zero)
                            Marshal.FreeCoTaskMem(ptrCopyData);
                    }
                }
           // }
        }


    }
}