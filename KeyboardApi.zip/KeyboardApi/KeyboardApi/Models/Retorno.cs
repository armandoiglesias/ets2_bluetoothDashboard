﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KeyboardApi.Models
{
    public class Retorno
    {
        public int id { get; set; }
        public string mensaje { get; set; }
    }
}